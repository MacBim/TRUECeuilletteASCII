import java.util.Random;

public class Agent {
	
	Position position;
	/*
	 * float interest;
	 * ...
	 * 
	 */

	public Position getPosition() {
		return position;
	}
	
	public Agent(Position position) {
		this.position = position;
	}
	
	public void setPosition(Position position) {
		this.position = position;
	}
	
	void move(GameIA gameIA, Position pos){
		Position oldPos = this.getPosition();
		gameIA.content[oldPos.getX()][oldPos.getY()] = gameIA.EMPTY_SPACE;
		this.setPosition(pos);
		int x = pos.getX();
		int y = pos.getY();
		gameIA.putAgent(this);
	}
	
	void moveRandom(GameIA gameIA){
		Random randomGenerator = new Random();
		int xRandom = randomGenerator.nextInt(gameIA.content.length);
		int yRandom = randomGenerator.nextInt(gameIA.content.length);
		Position randomPosition = new Position(xRandom, yRandom);
		this.move(gameIA, randomPosition);
	}
//	void moveRandomGauss(GameIA gameIA){
//		Random randomGenerator = new Random();
////		randomGenerator.setSeed(2);
//
//		System.out.println("x : "+xRandom+" y : "+yRandom+"\n");
//		Position randomPosition = new Position(xRandom, yRandom);
//		this.move(gameIA, randomPosition);
//	}
	
	void moveLeoSteps(GameIA gameIA){
		/*
		 *
		 * This function will move agent this way:
		 *  Agent (0) can only move in case right next to him (X)
		 *  Like this:   
		 *   XXX
		 *   XOX
		 *   XXX
		 * 
		 *  Agent will proceed a few moves like this and then will do a big jump and start again
		 *  i.e for A(x,y), move can be A(x +/- 1, y +/- 1)
		 */
		Random randomGenerator = new Random();
		int xRandom = randomGenerator.nextInt(gameIA.content.length);
		int yRandom = randomGenerator.nextInt(gameIA.content.length);
		Position randomPosition = new Position(xRandom, yRandom);
		this.move(gameIA, randomPosition);
	}
	
	
	float mC(){
		while(true){
			Random randomGenerator = new Random();
			float r1 = randomGenerator.nextFloat();
			float proba = r1;
			float r2 = randomGenerator.nextFloat();
			if(r2 > proba){
				return r1;
			}
		}
	}
	
	
	void moveLevy(GameIA gameIA){
		float mc = this.mC();
		
	}
}
